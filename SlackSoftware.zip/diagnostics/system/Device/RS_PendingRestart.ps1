﻿# Copyright © 2017, Microsoft Corporation. All rights reserved.
# :: ======================================================= ::
<#
	DESCRIPTION:	
	  RS_PendingRestart displays interaction with appropriate message
	ARGUMENTS:
	  
	RETURNS:
#>
#================================================================================
$RebootCalled = Get-DiagInput -Id "INT_RebootSystem"

