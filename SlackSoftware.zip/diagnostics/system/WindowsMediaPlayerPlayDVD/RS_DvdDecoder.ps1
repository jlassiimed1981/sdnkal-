# Copyright � 2008, Microsoft Corporation. All rights reserved.


#RS_DvdDecoder

$HelpMessage = Get-DiagInput -id IT_DvdDecoderHelp
