﻿# Copyright © 2017, Microsoft Corporation. All rights reserved.
# =============================================================

# Interaction to notify user to restart the sytem
Get-DiagInput -ID "INT_PendingRestart"
